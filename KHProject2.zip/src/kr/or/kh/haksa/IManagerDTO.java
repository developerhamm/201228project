package kr.or.kh.haksa;

public interface IManagerDTO {
	public abstract String getPart();
	public abstract void setPart(String part);
}
