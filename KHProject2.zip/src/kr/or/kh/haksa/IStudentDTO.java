package kr.or.kh.haksa;

public interface IStudentDTO {
	public abstract String getHakbun();
	public abstract void setHakbun(String hakbun);
}
